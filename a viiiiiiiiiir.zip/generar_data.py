import json, sys, re
import openpyxl
from collections import defaultdict

EXCEL = sys.argv[1] if len(sys.argv) > 1 else 'ANB_Planificacion_Optimizada.xlsx'

FLAG_MAP = {
    'CHINA':'CN','HONG KONG':'HK','MALAYSIA':'MY','PHILIPPINES':'PH',
    'VIETNAM':'VN','THAILAND':'TH','SINGAPORE':'SG','LAOS':'LA',
    'UNITED STATES':'US','MEXICO':'MX','PERU':'PE','CHILE':'CL',
    'BRAZIL':'BR','ECUADOR':'EC','GERMANY':'DE','PORTUGAL':'PT',
    'SPAIN':'ES','GREECE':'GR','SWITZERLAND':'CH','ALBANIA':'AL',
    'ISRAEL':'IL','EGYPT':'EG','UNITED ARAB EMIRATES':'AE','UNITED ARAB EMIRAT':'AE'
}
POOL_FLAG = {'China':'CN','MALAYSIA':'MY','PHILIPPINES':'PH','PERU':'PE'}
SOLAPAS = ['ASADO','PECHO','R&L HILTON','R&L W','RUEDA']
SKIP = {'Stock de cuartos','Rechazos','Degradado a MB1','Pasado a MB1'}
POOL_IDS = {'China','MALAYSIA','PHILIPPINES','PERU'}  # SALDO NO va aca: es el pendiente, no consumo

def process_excel(path):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    ws_dv = wb['DETALLE VENTAS']
    rows_dv = list(ws_dv.iter_rows(values_only=True))
    gen_kgu = defaultdict(list)
    for row in rows_dv[3:]:
        gen = str(row[10]) if row[10] else ''
        kgu = row[19]; kgv = row[16]
        if gen and gen != 'None' and isinstance(kgu,(int,float)) and kgu>0 and isinstance(kgv,(int,float)) and kgv>0:
            gen_kgu[gen].append((kgu, kgv))
    KGU = {gen: round(sum(v[0]*v[1] for v in vals)/sum(v[1] for v in vals), 3) for gen, vals in gen_kgu.items()}

    venta_solapa = {}
    sol_out = {}

    for solapa in SOLAPAS:
        if solapa not in wb.sheetnames:
            print(f"  ADVERTENCIA: '{solapa}' no encontrada"); continue
        ws = wb[solapa]
        rows = list(ws.iter_rows(values_only=True))
        header = rows[3]
        is_rlw = solapa == 'R&L W'
        genericos_mb1 = []; idx_mb1 = []
        for i, h in enumerate(header[10:], start=10):
            if not h: continue
            if str(h) in ('INSTRUCCIONES','ALERTAS','Sem','Venta','Concepto'): break
            genericos_mb1.append(str(h)); idx_mb1.append(i)
        genericos_mb2 = []; idx_mb2 = []
        if is_rlw:
            for i, h in enumerate(header[29:], start=29):
                if not h: continue
                if str(h) in ('INSTRUCCIONES','ALERTAS'): break
                genericos_mb2.append(str(h)+'__MB2'); idx_mb2.append(i)
        all_gens = genericos_mb1 + genericos_mb2
        gw = {g: {} for g in all_gens}
        current_week = None
        for row in rows[4:]:
            sem = row[0]; concepto = row[2]; venta_id = str(row[1]).strip() if row[1] else ''
            if sem and str(sem).startswith('W') and concepto == 'Stock de cuartos':
                current_week = str(sem)
                for g, idx in zip(genericos_mb1, idx_mb1):
                    v = row[idx] if idx < len(row) else None
                    if isinstance(v,(int,float)) and v != 0:
                        gw[g].setdefault(current_week, {'p':0,'e':[]})['p'] += round(float(v))
                for g, idx in zip(genericos_mb2, idx_mb2):
                    v = row[idx] if idx < len(row) else None
                    if isinstance(v,(int,float)) and v != 0:
                        gw[g].setdefault(current_week, {'p':0,'e':[]})['p'] += round(float(v))
            elif concepto in ('Producción','Produccion','Rechazos','Degradado a MB1','Pasado a MB1') and current_week:
                for g, idx in zip(genericos_mb1, idx_mb1):
                    v = row[idx] if idx < len(row) else None
                    if isinstance(v,(int,float)) and v != 0:
                        gw[g].setdefault(current_week, {'p':0,'e':[]})['p'] += round(float(v))
                for g, idx in zip(genericos_mb2, idx_mb2):
                    v = row[idx] if idx < len(row) else None
                    if isinstance(v,(int,float)) and v != 0:
                        gw[g].setdefault(current_week, {'p':0,'e':[]})['p'] += round(float(v))
            elif str(concepto) not in SKIP and venta_id and current_week:
                if venta_id == 'SALDO': continue   # fila de saldo (pendiente positivo), NO es consumo
                is_res = venta_id.startswith('R-')
                is_pool = venta_id in POOL_IDS
                if not is_res and not is_pool:
                    try: int(venta_id); venta_solapa[venta_id] = solapa
                    except ValueError: pass
                pais = ''; cliente = ''
                concepto_str = str(concepto or '')
                sep = '\u2502' if '\u2502' in concepto_str else ('|' if '|' in concepto_str else None)
                if sep:
                    parts = [p.strip() for p in concepto_str.split(sep)]
                    pais = parts[1].upper() if len(parts)>1 else ''
                    cliente = parts[2][:30] if len(parts)>2 else ''
                    if cliente.upper() == 'KOSHER':
                        cliente = 'Menaker'
                elif is_pool:
                    pais = venta_id.upper(); cliente = venta_id
                tipo = 'R' if is_res else ('C' if is_pool else 'V')
                for g, mb1_idx in zip(genericos_mb1, idx_mb1):
                    v = row[mb1_idx] if mb1_idx < len(row) else None
                    if isinstance(v,(int,float)) and v != 0:
                        kg = round(abs(float(v)) * KGU.get(g, 1.0))
                        f = POOL_FLAG.get(pais, FLAG_MAP.get(pais,''))
                        wkd = gw[g].setdefault(current_week, {'p':0,'e':[]})
                        found = next((e for e in wkd['e'] if e['p']==pais and e['t']==tipo and e['c']==cliente), None)
                        if found: found['kg'] += kg
                        else: wkd['e'].append({'p':pais,'c':cliente,'t':tipo,'kg':kg,'f':f})
                if is_rlw:
                    for g, mb2_idx in zip(genericos_mb2, idx_mb2):
                        v = row[mb2_idx] if mb2_idx < len(row) else None
                        if isinstance(v,(int,float)) and v != 0:
                            gen_base = g.replace('__MB2','')
                            kg = round(abs(float(v)) * KGU.get(gen_base, 1.0))
                            f = POOL_FLAG.get(pais, FLAG_MAP.get(pais,''))
                            wkd = gw[g].setdefault(current_week, {'p':0,'e':[]})
                            found = next((e for e in wkd['e'] if e['p']==pais and e['t']==tipo and e['c']==cliente), None)
                            if found: found['kg'] += kg
                            else: wkd['e'].append({'p':pais,'c':cliente,'t':tipo,'kg':kg,'f':f})
        sol_gen = {}
        for g in all_gens:
            gen_base = g.replace('__MB2','')
            kgu = KGU.get(gen_base, 1.0)
            last_v = None; week_out = {}
            for wk in sorted(gw[g].keys()):
                wn = int(wk[1:])
                if wn > 44: continue
                wd = gw[g][wk]
                week_out[wk] = {'p': round(wd['p'] * kgu), 'e': wd['e']}
                if any(e['t'] in ('V','C','R') for e in wd['e']): last_v = wk
            if week_out:
                sol_gen[g] = {'w': week_out, 'lv': last_v, 'kgu': kgu, 'mb': 'MB2' if '__MB2' in g else 'MB1'}
        sol_out[solapa] = {'g': sol_gen, 'go': [g for g in all_gens if g in sol_gen]}
        print(f"  {solapa}: {len(sol_gen)} genericos")

    cli_indiv = defaultdict(lambda: {'pais':'','flag':'','kg':0,'solapas':defaultdict(lambda: defaultdict(lambda: {'kg':0,'sem':{},'temps':set()}))})
    cong_pais = defaultdict(lambda: {'flag':'','kg':0,'clientes':set(),'solapas':defaultdict(lambda: defaultdict(lambda: {'kg':0,'sem':{}}))})
    for row in rows_dv[3:]:
        wc = row[0]; venta = str(row[5]).strip() if row[5] else ''
        pais = str(row[6]).upper() if row[6] else ''
        cliente = str(row[7]) if row[7] else ''
        generico = str(row[10]) if row[10] else ''
        tipo_prod = str(row[12]) if row[12] else ''
        kgv = row[16] if isinstance(row[16],(int,float)) else 0
        if not cliente or cliente in ('None','(en blanco)'): continue
        if not wc or not str(wc).startswith('W'): continue
        if venta.startswith('R-'): continue
        if not tipo_prod or tipo_prod == 'None': continue
        if kgv <= 0: continue
        wn = str(int(str(wc).replace('W','')))
        gen = generico if generico and generico != 'None' else '?'
        flag = FLAG_MAP.get(pais,'')
        gen_sol = venta_solapa.get(venta)
        if not gen_sol: continue
        if tipo_prod == 'Congelado':
            cp = cong_pais[pais]
            cp['flag'] = flag; cp['kg'] += kgv; cp['clientes'].add(cliente)
            gd = cp['solapas'][gen_sol][gen]
            gd['kg'] += kgv; gd['sem'][wn] = gd['sem'].get(wn,0) + kgv
        else:
            d = cli_indiv[cliente]
            if not d['pais'] and pais: d['pais']=pais; d['flag']=flag
            d['kg'] += kgv
            gd = d['solapas'][gen_sol][gen]
            gd['kg'] += kgv; gd['sem'][wn] = gd['sem'].get(wn,0) + kgv
            gd['temps'].add(tipo_prod)
    cli_out = {}
    for cli, d in sorted(cli_indiv.items(), key=lambda x:-x[1]['kg']):
        if d['kg'] < 500: continue
        solapas_out = {}
        for sol, gens in d['solapas'].items():
            gens_list = [{'g':gen,'kg':round(gd['kg']),'sem':{k:round(v) for k,v in sorted(gd['sem'].items(),key=lambda x:int(x[0]))},'temp':' + '.join(sorted(gd['temps'])) if gd['temps'] else ''} for gen,gd in sorted(gens.items(),key=lambda x:-x[1]['kg']) if gd['kg']>0]
            if gens_list:
                solapas_out[sol] = {'kg':round(sum(g['kg'] for g in gens_list)),'gens':gens_list}
        if solapas_out:
            cli_out[cli] = {'pais':d['pais'],'flag':d['flag'],'kg':round(d['kg']),'tipo':'enfriado','solapas':solapas_out}
    for pais_key, cp in sorted(cong_pais.items(), key=lambda x:-x[1]['kg']):
        if cp['kg'] < 500: continue
        nombre = f"{pais_key.title()} Congelado"
        solapas_out = {}
        for sol, gens in cp['solapas'].items():
            gens_list = [{'g':gen,'kg':round(gd['kg']),'sem':{k:round(v) for k,v in sorted(gd['sem'].items(),key=lambda x:int(x[0]))},'temp':'Congelado'} for gen,gd in sorted(gens.items(),key=lambda x:-x[1]['kg']) if gd['kg']>0]
            if gens_list:
                solapas_out[sol] = {'kg':round(sum(g['kg'] for g in gens_list)),'gens':gens_list}
        if solapas_out:
            cli_out[nombre] = {'pais':pais_key,'flag':cp['flag'],'kg':round(cp['kg']),'tipo':'congelado','clientes':sorted(cp['clientes']),'solapas':solapas_out}
    cli_out = dict(sorted(cli_out.items(), key=lambda x:-x[1]['kg']))
    print(f"  Clientes: {len(cli_out)}")
    return sol_out, cli_out

# tag del dia desde el nombre de archivo (igual que data.js: "del dia: -44")
m = re.search(r'Optimizada([-_].+?)\.xlsx', EXCEL)
tag = m.group(1) if m else ''

sol_out, cli_out = process_excel(EXCEL)
cli_names = list(cli_out.keys())
cli_array = list(cli_out.values())

# ============================================================
#  AUTOVALIDACION: reconcilia cada celda contra la fila SALDO
#  del Excel (que es la verdad). Si algo no cierra, AVISA y NO
#  deja subir el archivo a ciegas.
# ============================================================
def validar(path, sol_out, tol=3):
    wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    fallas = []
    for solapa in SOLAPAS:
        if solapa not in wb.sheetnames or solapa not in sol_out: continue
        ws = wb[solapa]; rows = list(ws.iter_rows(values_only=True)); header = rows[3]
        gens=[]; idx=[]
        for i,h in enumerate(header[10:],start=10):
            if not h: continue
            if str(h) in ('INSTRUCCIONES','ALERTAS','Sem','Venta','Concepto'): break
            gens.append(str(h)); idx.append(i)
        cur=None; saldo_excel={}
        for r in rows[4:]:
            if r[0] and str(r[0]).startswith('W') and r[2]=='Stock de cuartos': cur=str(r[0])
            if (str(r[1]).strip() if r[1] else '')=='SALDO' and cur:
                for g,c in zip(gens,idx):
                    v=r[c] if c<len(r) else None
                    saldo_excel.setdefault(cur,{})[g]=float(v) if isinstance(v,(int,float)) else 0.0
        for g in gens:
            gd = sol_out[solapa]['g'].get(g)
            if not gd: continue
            kgu = gd['kgu'] or 1.0
            for wk,wd in gd['w'].items():
                if wk not in saldo_excel: continue
                excel = saldo_excel[wk].get(g,0.0)                 # cuartos
                calc  = (wd['p'] - sum(e['kg'] for e in wd['e']))/kgu
                if abs(calc-excel) > tol:
                    fallas.append((solapa,g,wk,round(excel),round(calc),round(calc-excel)))
    return fallas

fallas = validar(EXCEL, sol_out)

print("\n----- RESUMEN -----")
for s in sol_out:
    gs=sol_out[s]['go']; W=sol_out[s]['g']
    p=sum(w['p'] for g in gs for w in W[g]['w'].values())
    v=sum(e['kg'] for g in gs for w in W[g]['w'].values() for e in w['e'] if e['t']=='V')
    c=sum(e['kg'] for g in gs for w in W[g]['w'].values() for e in w['e'] if e['t']=='C')
    rr=sum(e['kg'] for g in gs for w in W[g]['w'].values() for e in w['e'] if e['t']=='R')
    print(f"  {s:12} prod={p:>10,}  vendido={v:>9,}  pool={c:>8,}  reserva={rr:>8,}  FALTA={p-v-c-rr:>10,}")
print(f"  Clientes: {len(cli_names)}")

if fallas:
    print("\n" + "="*60)
    print(f"  ⚠  ATENCION: {len(fallas)} celdas NO cierran con el SALDO del Excel")
    print("  NO subas este data.js. Avisale a Claude y pegale estas filas:")
    print("="*60)
    for f in fallas[:25]:
        print(f"   {f[0]} | {f[1]} | {f[2]} | SALDO Excel={f[3]} vs calculado={f[4]} (dif {f[5]})")
    if len(fallas)>25: print(f"   ... y {len(fallas)-25} mas")
    print("\n  >>> data.js NO se genero (por seguridad).")
    raise SystemExit(1)

# Solo si TODO reconcilia, escribe el archivo
data_js = (
    f"// ANB Planificación — DATOS (generado desde el Excel del día: {tag})\n"
    f"// Solo datos. El diseño y la lógica viven en index.html.\n"
    f"const SOL = {json.dumps(sol_out, ensure_ascii=False)};\n"
    f"const CNAMES = {json.dumps(cli_names, ensure_ascii=False)};\n"
    f"const CLI = {json.dumps(cli_array, ensure_ascii=False)};\n"
)
open('data.js','w',encoding='utf-8').write(data_js)
print(f"\n  ✓ VALIDADO: las {sum(1 for s in sol_out for g in sol_out[s]['g'] for _ in sol_out[s]['g'][g]['w'])} celdas cierran con el SALDO del Excel.")
print(f"  ✓ data.js generado OK (tag: {tag}, {len(data_js):,} bytes)")
